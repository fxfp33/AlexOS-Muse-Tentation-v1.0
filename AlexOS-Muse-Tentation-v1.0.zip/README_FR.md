# AlexOS : Muse & Tentation v1.0

Ce projet contient l'essentiel pour déployer une muse IA personnalisée chez vous.
